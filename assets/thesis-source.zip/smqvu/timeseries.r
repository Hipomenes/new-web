require(zoo)
data <- read.csv(file="results.csv",sep=",",head=TRUE)
cum  = zoo(data$dcomp, as.Date(data$date))
data = zoo(data$cbytes, as.Date(data$date))
data <- aggregate(data, identity, tail, 1)
cum  <- aggregate(cum, identity, sum, 1)
days = seq(start(data), end(data), "day")
data2 = na.locf(merge(data, zoo(,days)))

pdf(file='timeseries.pdf',width=9,height=4.5)
plot(data2,xlab='',ylab='entropy (bytes)',ylim=c(0, 150000))
lines(cum,type="h",col=rgb(0.64,0.08,0.00))

axis.Date(side = 1, days, format="%m-%Y", at=c("2009-05-26", "2010-07-07"),col=rgb(0.5,0.5,0.5), lwd=0.5)