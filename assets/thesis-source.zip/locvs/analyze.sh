#!/bin/sh

REPOS=locus
FILE=trunk/Application/locvs.xml
NAME=locvs.xml
VS=$(svnlook history $REPOS $FILE  | awk 'NR > 2' | sort)
VERSIONS=$(svnlook history $REPOS $FILE | awk 'NR > 2 { print $1 }')
IFS=$'\n'

echo date,revision,file,lines,nclass,nattr,nrel,bytes,compressed,diff,dcomp > summary.csv
for v in $VS; do
	rev=$(echo $v | awk '{ print $1 }')
	f=$(echo $v | awk '{ print $2 }')
    rev_date=$(svnlook date -r $rev $REPOS | awk '{ print $1 }')
    new_file=dump/${rev_date}_${rev}_${NAME}
   
    svnlook cat -r $rev $REPOS $f > $new_file	
	bzip2 -k9 $new_file 

    wc=$(wc -lc $new_file)
    lines=$(echo $wc | awk '{ print $1 }')
	bytes=$(echo $wc | awk '{ print $2 }')
    comp=$(ls -l $new_file.bz2 | awk '{ print $5 }')
    
    nclass=$(cat $new_file | grep "<entity id=" | wc -l | awk '{ print $1 }')
    nattr=$(cat $new_file | grep "<attr id=" | wc -l | awk '{ print $1 }')
    nrel=$(cat $new_file | grep "<relationship id=" | wc -l | awk '{ print $1 }')

	if [[ -z "${prev_file}" ]] ; then
		diff=0
		dcomp=0
	else
	    diff_file=dump/${rev_date}_${rev}_${NAME}.diff
	    diff -dw $new_file $prev_file > $diff_file
	    bzip2 -k9 $diff_file
	    diff=$(cat $diff_file | egrep -c '^[<>]')
	    dcomp=$(ls -l $diff_file.bz2 | awk '{ print $5 }')
	fi

    echo $rev_date,$rev,$f,$lines,$nclass,$nattr,$nrel,$bytes,$comp,$diff,$dcomp
    echo $rev_date,$rev,$f,$lines,$nclass,$nattr,$nrel,$bytes,$comp,$diff,$dcomp >> summary.csv

    prev_file=$new_file
done