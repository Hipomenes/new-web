require(zoo)
require(plotrix)
data <- read.csv(file="summary.csv",sep=",",head=TRUE)
nattr = zoo(data$nattr, as.Date(data$date))
nattr <- aggregate(nattr, identity, tail, 1)

days = seq(start(nattr), end(nattr), "day")

nattr2  = na.locf(merge(nattr, zoo(,days)))

pdf(file='nattr.pdf',width=9,height=3)
stackpoly(nattr2,xlab='',ylab='attributes (n)',col=rgb(0.18,0.34,0.55))