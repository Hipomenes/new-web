require(zoo)
data <- read.csv(file="summary.csv",sep=",",head=TRUE)
nclass = zoo(data$nrel, as.Date(data$date))
nclass <- aggregate(nclass, identity, tail, 1)
days = seq(start(nclass), end(nclass), "day")

nclass2 = na.locf(merge(nclass, zoo(,days)))

pdf(file='nrel.pdf',width=9,height=3)
plot(nclass2,xlab='',ylab='relations (n)',col=rgb(0.18,0.34,0.55))