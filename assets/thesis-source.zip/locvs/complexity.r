require(zoo)
library(ggplot2)

pdf(file='complexity.pdf',width=9,height=3)

data <- read.csv(file="summary.csv",sep=",",head=TRUE)
nclass = zoo(data$nclass, as.Date(data$date))
nclass <- aggregate(nclass, identity, tail, 1)
nattr = zoo(data$nattr, as.Date(data$date))
nattr <- aggregate(nattr, identity, tail, 1)
nrel = zoo(data$nrel, as.Date(data$date))
nrel <- aggregate(nrel, identity, tail, 1)

days = seq(start(nclass), end(nclass), "day")

nclass2 = na.locf(merge(nclass, zoo(,days)))
nattr2 = na.locf(merge(nattr, zoo(,days)))
nrel2 = na.locf(merge(nrel, zoo(,days)))

dataABCts <- merge(nclass2,nattr2,nrel2)

# EDIT: Change labels here
colnames(dataABCts) <- c("Classes","Attributes","Relations")

stacked <- lapply(colnames(dataABCts),function(i) {
  data.frame(date=index(dataABCts),values=dataABCts[,i],ind=i)
})

stacked <- do.call(rbind,stacked)

ggplot(stacked, aes(x=date, y=values)) + geom_area(aes(fill=factor(ind)), grid.fill = "white", xlab='', ylab='count (n)')

last_plot() + opts(panel.grid.minor = theme_blank()) 
last_plot() + opts(panel.grid.major = theme_blank()) 
last_plot() + opts(panel.background = theme_blank()) 
last_plot() + opts(axis.title.x = theme_blank(), axis.title.y = theme_blank())
last_plot() + opts(axis.line = theme_segment())
