library(lattice)
library(stats)
data <- read.csv(file='LS2.5.csv',head=TRUE,sep=',')
pdf(file='LS2.5.pdf',width=9,height=3)
colors=c(rgb(0.55,0.18,0.10,1), rgb(0.55,0.18,0.10,0.8), rgb(0.02,0.17,0.22,0.6), rgb(0.20,0.33,0.03,0.8), rgb(0.20,0.33,0.03,1))
histogram( ~ Answer | Type, data=data, col=colors,border=c(rgb(1, 1, 1)),ylab='%',xlab='',breaks=c(0.5:5.5),xlim=c(0.3,5.7),right=TRUE,left=FALSE,strip=strip.custom(bg=rgb(0,0,0,0)))
dev.off()
x <- data$Answer[1:9]
y <- data$Answer[10:18]
wilcox.test(x, y, alternative="l")
