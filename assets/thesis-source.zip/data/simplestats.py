print "Loading Questionnaire..."
f = open('questionnaire.csv', 'r')
fw = open('simplestats.tex', 'w')

for line in f:
	data = line.rsplit(',')
	q = data[0]
	e = {}
	b = {}
	
	for val in xrange(1, 6):
		e[val] = 0
		b[val] = 0
		
	for val in xrange(1, 10):
		v = int(data[val])
		e[v] = e[v] + 1
	
	for val in xrange(13, 22):
		v = int(data[val])
		b[v] = b[v] + 1
	
	mo = data[10]
	do = data[11]
	mb = data[22]
	db = data[23]
	ty = data[24]
	tt = data[25]
	w  = data[26]
	pe = data[27]
	pl = data[28]
	pg = data[29]
	
	if ty == '=':
		val = pe; ty = '$\\neq$'
	elif ty == '<': 
		val = pl; ty = '$<$'
	else:
		val = pg; ty = '$>$'
	
	fw.write(q + ' & \\hspace{0cm}\\ratiofivespark{9}{' + str(e[1]) + '}{' + str(e[2]) + '}{' + str(e[3]) + '}{' + str(e[4]) + '}{' + str(e[5]) + '} & '+ mo + ' & ' + do + ' & \\hspace{0cm}\\ratiofivespark{9}{' + str(b[1]) + '}{' + str(b[2]) + '}{' + str(b[3]) + '}{' + str(b[4]) + '}{' + str(b[5]) + '} & '+ mb + ' & ' + db + ' & ' + ty + ' & ' + w + ' & ' + val + ' \\\\ \n')
	
fw.close()
f.close()