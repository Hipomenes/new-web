col1, col2 = "Answer", "Type"

print "Loading Questionnaire..."
f = open('questionnaire.csv', 'r')
ftex = open('questionnaire.tex', 'w')
objs = ''

for line in f:
	data = line.rsplit(',')
	q = data[0]
	objs = objs+q+'.pdf '
	fw = open(q+'.csv', 'w')
	fw.write(col1+', '+col2+'\n')
	for val in xrange(1, 10):
		fw.write(data[val]+', Experimental\n')
	for val in xrange(13, 22):
		fw.write(data[val]+', Baseline\n')
	fw.close()
	
	mo = data[10]
	do = data[11]
	mb = data[22]
	db = data[23]
	ty = data[24]
	tt = data[25]
	w  = data[26]
	pe = data[27]
	pl = data[28]
	pg = data[29]
	
	if ty == '=':
		val = pe; ty = "$H_1: G_e \\neq G_b$"
	elif ty == '<':
		val = pl; ty = "$H_1: G_e < G_b$"
	else:
		val = pg; ty = "$H_1: G_e > G_b$"
	
	qtext = data[30].rsplit('\r')[0]
	significance = 'no significant'
	if float(val) < 0.01:
		significance = 'highly significant'
	elif float(val) < 0.05:
		significance = 'significant'
		
	ftex.write('\subsubsection{'+qtext+'} \n')
	ftex.write('\label{sec:quest-'+q+'}\n')
	ftex.write('\statanalysis{'+q+'}{' + mo + '}{' + do + '}{' + mb + '}{' + db + '}{' + val + '}{' + significance + '}{' + ty + '} \n')
	ftex.write('\histogram{'+q+'}{'+qtext+'} \n\n')
	
ftex.close()
f.close()
	
print objs