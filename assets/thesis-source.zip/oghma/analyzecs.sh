#!/bin/sh

REPOS=oghma.git

# Oghma 2.0
# HEAD=201c9130b4b93e693b9e410b6e5fc5c228053bb7

# Oghma 1.3
HEAD=5860608d1e08780c28c15f62adf2ad0f4c3e3c05
OUTPUT=../dump/results.csv
AUX=../dump/files.lst
IFS=$'\n'

cd $REPOS
git checkout $HEAD

echo version,date,loc,bytes,cbytes,diff,dcomp > $OUTPUT

VERSIONS=$(git log --format="%h %cd" --date=short --first-parent | perl -e 'print reverse <>' )
for v in $VERSIONS; do
	rev=$(echo $v | awk '{ print $1 }')
	date=$(echo $v | awk '{ print $2 }')
	amalg=../dump/${date}_${rev}_amalgamation.cs
	
	git checkout $rev
	
	FILES=$(find . -type f -name "*.cs")
	#FILES=$(find . -type f -name "*.cs" -exec wc -l {} \;)
	
	echo " " > $amalg	
	
	for f in $FILES; do
		cat $f >> $amalg
	done
	
	loc=$(wc -l $amalg | awk '{ print $1 }')
	bytes=$(ls -l $amalg | awk '{ print $5 }')
	
	bzip2 -k9 $amalg
	cbytes=$(ls -l $amalg.bz2 | awk '{ print $5 }')

	if [[ -z "${prev_file}" ]] ; then
		echo $rev,$date,$loc,$bytes,$cbytes,$bytes,$cbytes
		echo $rev,$date,$loc,$bytes,$cbytes,$bytes,$cbytes >> $OUTPUT
	else
		diff_file=$amalg.diff
    	diff -dw $amalg $prev_file > $diff_file
    	bzip2 -k9 $diff_file
    	diff=$(cat $diff_file | egrep -c '^[<>]')
    	dcomp=$(ls -l $diff_file.bz2 | awk '{ print $5 }')

		if [[ $diff -ne 0 ]] ; then
			echo $rev,$date,$loc,$bytes,$cbytes,$diff,$dcomp
			echo $rev,$date,$loc,$bytes,$cbytes,$diff,$dcomp >> $OUTPUT
		fi
	fi
	
	prev_file=$amalg
done